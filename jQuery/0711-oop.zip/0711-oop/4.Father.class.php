<?php
include '../functions.php';
/*
class Controller{
	public function __construct() {
		echo 'Controller的__construct自动执行了';
	}
}

class Index extends Controller{

}

//如果子类继承父类，实例化子类，父类的构造方法会自动执行
$c = new Index();
*/



/*
class Controller{
	public function __construct() {
		echo 'Controller的__construct自动执行了';
	}
}

class Index extends Controller{
	public function __construct() {
		echo 'Index的__construct自动执行了';

	}
}

//子类继承父类，实例化子类，
//如果子类和父类同时拥有构造方法，
//只执行子类的构造方法，（子类的构造方法覆盖了父类的构造方法）
$c = new Index();
*/











