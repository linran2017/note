<?php
class Base{
	public function index(){
		echo 'Base index';
	}
}