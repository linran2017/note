<?php
class Model{
	public function index(){
		echo 'Model index';
	}
}