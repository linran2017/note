<?php
class Base{
	public function get(){
		echo 'base get';
	}

	public function find($id){
		echo $id;
	}
}